#!/bin/bash

# From:
#   http://stackoverflow.com/questions/59895/can-a-bash-script-tell-what-directory-its-stored-in
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Grab the current project name from the project.clj file
PROJECT_NAME=`echo -e "\
with open('$DIR/../project.clj', 'r') as f:\n\
    for line in f:\n\
        if(line.find('defproject')):\n\
            print line.split(' ')[1].strip(); break" | python`

# Grab the current version from the project.clj file
PROJECT_VERSION=`echo -e "\
with open('$DIR/../project.clj', 'r') as f:\n\
    for line in f:\n\
        if(line.find('defproject')):\n\
            print line.split(' ')[-1].strip()[1:-1]; break" | python`

# Target executable path agnostic of version
PROJECT_EXE="${DIR}/../target/${PROJECT_NAME}-${PROJECT_VERSION}-standalone.jar"

JAVA=`which java 2>/dev/null`

if [ -z "${JAVA}" ]; then
    echo "ERROR: Cannot find a version of java, please install and try again."
    exit 1
fi

exec_project() {
    ${JAVA} -jar ${PROJECT_EXE} $* 2>/dev/null
}

if [[ -f `ls ${PROJECT_EXE} 2>/dev/null` ]]; then
    exec_project $*
else
    local lein=`which lein 2>/dev/null`
    if [ -z "${lein}" ]; then
        lein_url="https://raw.githubusercontent.com/technomancy/leiningen/stable/bin/lein"
        lein_script_dir="${DIR}/../resources"
        lein_script_loc="${lein_script_dir}/lein"
        
        mkdir -p "${lein_script_dir}"

        # first check if we have curl installed and, if so, download Leiningen
        [ -n "`which curl 2>/dev/null`" ] && \
          curl ${lein_url} > ${lein_script_loc} && \
          chmod 750 ${lein_script_loc}
        # if the `lein` file still doesn't exist, lets try `wget` and cross our fingers
        [ ! -f "${lein_script_loc}" ] && \
          [ -n "`which wget 2>/dev/null`" ] && \
          wget -O ${lein_script_loc} ${lein_url} && \
          chmod 750 ${lein_script_loc}
        # if both weren't successful, exit
        [ ! -f "${lein_script_loc}" ] && \
          echo "ERROR: Cannot find or download a version of leiningen, please install and try again." && \
          exit 2

        lein=${lein_script_loc}
    fi
    ${lein} do clean, javac, compile, uberjar
    exec_project $*
fi
